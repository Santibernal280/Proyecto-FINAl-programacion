import { Vehiculo } from "./vehiculo";

export const VEHICULOS: Vehiculo[]=[
    {id:1, marca:'Toyota',modelo:'Corolla',anio:'2023', 
        color:'Blancos', precio:'20000'},
        {id:2, marca:'Honda',modelo:'Civic',anio:'2022', 
          color:'Negro', precio:'22000'},
          {id:3, marca:'Tesla',modelo:'Model 3',anio:'2023', 
            color:'Rojo', precio:'35000'}
]