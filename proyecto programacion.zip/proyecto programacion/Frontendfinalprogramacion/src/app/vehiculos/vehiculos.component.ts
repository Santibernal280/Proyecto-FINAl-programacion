import { Component, OnInit } from '@angular/core';
import { Vehiculo } from './vehiculo';
import { VehiculosService } from './vehiculos.service';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import Swal from 'sweetalert2';



@Component({
  selector: 'app-vehiculos',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './vehiculos.component.html',
  styleUrl: './vehiculos.component.css'
})
export class VehiculosComponent implements OnInit {
  
  vehiculos:Vehiculo[];

  constructor(private vehiculosService: VehiculosService){

  }
  
  ngOnInit(): void {
    this.vehiculosService.getVehiculos().subscribe(
      vehiculos => this.vehiculos = vehiculos
    )
  }

  //invocando el método de eliminar
  delete(vehiculo:Vehiculo):void{
    Swal.fire({
      title: "Esta segur@?",
      text: `Seguro deseas eliminar la Vehiculo: ${vehiculo.marca} !`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Si, Eliminar!"
    }).then((result) => {
      if (result.isConfirmed) {
        this.vehiculosService.delete(vehiculo.id).subscribe(
          response=>{
            this.vehiculos = this.vehiculos.filter(veh=> veh !== vehiculo)
            Swal.fire({
              title: "Borrada!",
              text: `Tu Vehiculo ha sido eliminada: ${vehiculo.marca}`,
              icon: "success"
            });
          }
        )
      }
    });
  }

}
