import { Component } from '@angular/core';
import { Vehiculo } from './vehiculo';
import { FormsModule } from '@angular/forms';
import { VehiculosComponent } from './vehiculos.component';
import { VehiculosService } from './vehiculos.service';
import { Router, ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-form',
  standalone: true,
  imports: [FormsModule, VehiculosComponent, CommonModule],
  templateUrl: './form.component.html'
})
export class FormComponent {
  public vehiculo: Vehiculo = new Vehiculo()

  titulo:string="Formulario de Ingreso de Vehiculos"


  constructor(private vehiculoService: VehiculosService, private router: Router,
    private activatedRouted: ActivatedRoute
  ){}
  
  ngOnInit(){
    this.cargarVehiculo()
  }

  //cargar la tarea actual
  cargarVehiculo(): void{
    this.activatedRouted.params.subscribe(params => {
      let id = params['id']
      if(id){
        this.vehiculoService.getVehiculo(id).subscribe( (vehiculo) => this.vehiculo = vehiculo)
      }
    })
  }

  //Actualizar tarea
  update():void{
    this.vehiculoService.update(this.vehiculo).subscribe(vehiculo=> {
      this.router.navigate(['/vehiculos'])
      Swal.fire('Vehiculo Actualizada', `Vehiculo: ${vehiculo.marca} Actualizada con éxito!`, 'success')
    })
  }


  public create():void{
  //console.log("clicked");
  console.log(this.vehiculo);

  this.vehiculoService.create(this.vehiculo).subscribe(vehiculo =>
    {this.router.navigate(["/vehiculos"])
      Swal.fire('Nueva vehiculo', `Vehiculo: ${vehiculo.marca} creado con éxito`, 'success')
    }
  );
  }
}
