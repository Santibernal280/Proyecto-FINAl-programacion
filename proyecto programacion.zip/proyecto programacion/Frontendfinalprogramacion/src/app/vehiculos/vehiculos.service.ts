import { Injectable } from '@angular/core';
import { map, Observable, of } from 'rxjs';
import { Vehiculo } from './vehiculo';
import { VEHICULOS } from './vehiculos.json';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class VehiculosService {

  private urlEndpoint:string="http://localhost:9000/api/ventasc"

  private httpHeaders = new HttpHeaders({'Content-Type':'application/json'})

  constructor(private http: HttpClient) { }

  //buscar vehiculos de la base de datos
  getVehiculos():Observable<Vehiculo[]>{
    
   //return of (VEHICULOS);
   return this.http.get(this.urlEndpoint).pipe(
    map((response)=> response as Vehiculo[])
   )
  }

  //Método de crear tarea
  create(vehiculo:Vehiculo):Observable<Vehiculo>{
      return this.http.post<Vehiculo>(this.urlEndpoint, vehiculo, {headers:this.httpHeaders})
  }

  //Método de editar tarea
  getVehiculo(id: any):Observable<Vehiculo>{
    return this.http.get<Vehiculo>(`${this.urlEndpoint}/${id}`)
  }

  //Edición final
  update(vehiculo: Vehiculo):Observable<Vehiculo>{
    return this.http.put<Vehiculo>(`${this.urlEndpoint}/${vehiculo.id}`, vehiculo, {headers:this.httpHeaders})
  }

  //Eliminar
  delete(id:number):Observable<Vehiculo>{
    return this.http.delete<Vehiculo>(`${this.urlEndpoint}/${id}`, {headers:this.httpHeaders})
  }

}
