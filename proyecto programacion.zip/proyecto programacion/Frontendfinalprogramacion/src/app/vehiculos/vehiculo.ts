export class Vehiculo {

    id:number;
    marca:string;
    modelo: string;
    anio:string;
    color:string;
    precio:string;
}
