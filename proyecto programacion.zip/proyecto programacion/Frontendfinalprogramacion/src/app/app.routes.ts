import { Routes } from '@angular/router';
import { VehiculosComponent } from './vehiculos/vehiculos.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { ResponsablesComponent } from './responsables/responsables.component';
import { FormComponent } from './vehiculos/form.component';

export const routes: Routes = [
    {path:'', redirectTo:'/vehiculos', pathMatch:'full'},
    {path:'vehiculos', component:VehiculosComponent},
    {path:'header', component: HeaderComponent},
    {path:'footer', component:FooterComponent},
    {path:'responsables', component:ResponsablesComponent},
    {path:'vehiculos/form', component:FormComponent},
    {path:'vehiculos/form/:id', component:FormComponent},
];
