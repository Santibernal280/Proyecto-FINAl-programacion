import { Component } from '@angular/core';

@Component({
  selector: 'app-responsables',
  standalone: true,
  imports: [],
  templateUrl: './responsables.component.html',
  styleUrl: './responsables.component.css'
})
export class ResponsablesComponent {

}
