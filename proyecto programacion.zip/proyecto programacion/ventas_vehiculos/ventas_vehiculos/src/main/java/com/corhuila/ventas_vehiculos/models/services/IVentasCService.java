package com.corhuila.ventas_vehiculos.models.services;

import com.corhuila.ventas_vehiculos.models.entity.VentasC;

import java.util.List;

public interface IVentasCService {
    public List<VentasC> findAll();

    public VentasC findById(Long id);

    public VentasC save(VentasC ventasc);

    public void delete(Long id);
}
