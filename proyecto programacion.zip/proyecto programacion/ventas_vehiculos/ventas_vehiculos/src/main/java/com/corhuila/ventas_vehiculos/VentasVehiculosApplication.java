package com.corhuila.ventas_vehiculos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VentasVehiculosApplication {

	public static void main(String[] args) {
		SpringApplication.run(VentasVehiculosApplication.class, args);
	}

}
