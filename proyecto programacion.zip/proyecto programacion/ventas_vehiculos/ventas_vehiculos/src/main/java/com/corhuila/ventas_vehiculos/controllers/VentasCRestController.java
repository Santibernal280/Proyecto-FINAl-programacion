package com.corhuila.ventas_vehiculos.controllers;

import com.corhuila.ventas_vehiculos.models.entity.VentasC;
import com.corhuila.ventas_vehiculos.models.services.IVentasCService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = {"http://localhost:64683/"})//el puerto del frontend
@RestController
@RequestMapping("/api")
public class VentasCRestController {
    @Autowired
    private IVentasCService iVentasCService;

    @GetMapping("/ventasc")
    public List<VentasC> index(){
        return iVentasCService.findAll();
    }
    @GetMapping("/ventasc/{id}")
    public VentasC show(@PathVariable Long id){
        return iVentasCService.findById(id);
    }

    @PostMapping("/ventasc")
    @ResponseStatus(HttpStatus.CREATED)
    public VentasC create(@RequestBody VentasC ventasc){
        return iVentasCService.save(ventasc);
    }

    @PutMapping("/ventasc/{id}")
    @ResponseStatus(HttpStatus.CREATED)
    public VentasC update(@RequestBody VentasC inventor, @PathVariable Long id){
        VentasC ventascActual = iVentasCService.findById(id);

        ventascActual.setMarca(inventor.getMarca());
        ventascActual.setModelo(inventor.getModelo());
        ventascActual.setAnio(inventor.getAnio());
        ventascActual.setColor(inventor.getColor());
        ventascActual.setPrecio(inventor.getPrecio());


        return iVentasCService.save(ventascActual);
    }

    @DeleteMapping("/ventasc/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id){
        iVentasCService.delete(id);
    }
}
