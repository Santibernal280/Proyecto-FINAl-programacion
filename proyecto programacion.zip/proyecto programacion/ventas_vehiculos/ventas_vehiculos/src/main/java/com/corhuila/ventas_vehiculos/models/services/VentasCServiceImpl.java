package com.corhuila.ventas_vehiculos.models.services;

import com.corhuila.ventas_vehiculos.models.dao.IVentasCDao;
import com.corhuila.ventas_vehiculos.models.entity.VentasC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class VentasCServiceImpl implements IVentasCService {
    @Autowired
    private IVentasCDao ventasCDao;
    @Override
    @Transactional(readOnly = true)
    public List<VentasC> findAll() {
        return (List<VentasC>) ventasCDao.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public VentasC findById(Long id) {
        return ventasCDao.findById(id).orElse(null);
    }

    @Override
    @Transactional
    public VentasC save(VentasC inventor) {
        return ventasCDao.save(inventor);
    }

    @Override
    @Transactional
    public void delete(Long id) {
        ventasCDao.deleteById(id);
    }
}
