package com.corhuila.ventas_vehiculos.models.dao;

import com.corhuila.ventas_vehiculos.models.entity.VentasC;
import org.springframework.data.repository.CrudRepository;

public interface IVentasCDao extends CrudRepository<VentasC, Long> {
}
