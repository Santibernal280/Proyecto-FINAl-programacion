package com.corhuila.ventas_vehiculos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VentasVehiculosApplicationTests {

	@Test
	void contextLoads() {
	}

}
